rm -f assignment2.zip 
zip -r assignment2.zip "q1_schedule.py" "q2_linear.py" "q3_nature.py"
